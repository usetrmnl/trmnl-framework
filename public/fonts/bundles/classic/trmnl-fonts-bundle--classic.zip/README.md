# Classic bundle

Three single-weight pixel fonts.

This zip contains every font file required by the **Classic** bundle of the
[TRMNL Framework](https://trmnl.com), together with the **Inter Variable** typeface
used on high-density displays. Activate the bundle in your markup by adding
`screen--fonts-classic` to the screen root.

Released on 2026-08-22.

## Pixel fonts


### NicoPups

Used for descriptions, small labels, and metadata.

- **Designed at:** 16px pixel height
- **Weights:** normal
- **Formats:** ttf
- **Designer:** Emily Huo (emhuo), <https://emhuo.itch.io/nico-pixel-fonts-pack>
- **License:** SIL Open Font License v1.1, <https://scripts.sil.org/OFL>
- **Copyright:** Copyright (c) 2021, Emily Huo

Files included:

- `NicoPups-Regular.ttf`



### NicoClean

The workhorse font, used for labels, rich text body copy, and title-bar text.

- **Designed at:** 16px pixel height
- **Weights:** normal
- **Formats:** ttf
- **Designer:** Emily Huo (emhuo), <https://emhuo.itch.io/nico-pixel-fonts-pack>
- **License:** SIL Open Font License v1.1, <https://scripts.sil.org/OFL>
- **Copyright:** Copyright (c) 2021, Emily Huo

Files included:

- `NicoClean-Regular.ttf`



### BlockKie

Used for titles and large rich-text. The largest pixel font in the Classic bundle.

- **Designed at:** 26px pixel height
- **Weights:** normal
- **Formats:** ttf
- **Designer:** JoohnFonts, <https://fontstruct.com/fontstructors/show/1669437/joohnfonts>
- **License:** Creative Commons Attribution 3.0 Unported (CC BY 3.0), <https://creativecommons.org/licenses/by/3.0/>
- **Copyright:** Copyright (c) 2021 JoohnFonts
- **Source:** <https://fonts2u.com/blockkie-regular.font>

Files included:

- `BlockKie.ttf`




## High-density font


### Inter Variable

Used on high-density displays in both bundles for legibility.

- **Weights:** normal, italic
- **Designer:** Rasmus Andersson, <https://rsms.me/inter>
- **License:** SIL Open Font License v1.1, <https://scripts.sil.org/OFL>
- **Copyright:** Copyright 2016 The Inter Project Authors (https://github.com/rsms/inter)

Files included:

- `Inter.ttf`

- `Inter-Italic.ttf`




## License notices


### SIL Open Font License v1.1

Applies to: NicoPups, NicoClean, Inter Variable.


Each font listed above ships under its own copyright but uses the same license.
The full SIL Open Font License v1.1 text is reproduced below per the license's
redistribution requirements.

```
SIL OPEN FONT LICENSE Version 1.1 - 26 February 2007

PREAMBLE
The goals of the Open Font License (OFL) are to stimulate worldwide
development of collaborative font projects, to support the font creation
efforts of academic and linguistic communities, and to provide a free and
open framework in which fonts may be shared and improved in partnership
with others.

The OFL allows the licensed fonts to be used, studied, modified and
redistributed freely as long as they are not sold by themselves. The
fonts, including any derivative works, can be bundled, embedded,
redistributed and/or sold with any software provided that any reserved
names are not used by derivative works. The fonts and derivatives,
however, cannot be released under any other type of license. The
requirement for fonts to remain under this license does not apply
to any document created using the fonts or their derivatives.

DEFINITIONS
"Font Software" refers to the set of files released by the Copyright
Holder(s) under this license and clearly marked as such. This may
include source files, build scripts and documentation.

"Reserved Font Name" refers to any names specified as such after the
copyright statement(s).

"Original Version" refers to the collection of Font Software components as
distributed by the Copyright Holder(s).

"Modified Version" refers to any derivative made by adding to, deleting,
or substituting -- in part or in whole -- any of the components of the
Original Version, by changing formats or by porting the Font Software to a
new environment.

"Author" refers to any designer, engineer, programmer, technical
writer or other person who contributed to the Font Software.

PERMISSION & CONDITIONS
Permission is hereby granted, free of charge, to any person obtaining
a copy of the Font Software, to use, study, copy, merge, embed, modify,
redistribute, and sell modified and unmodified copies of the Font
Software, subject to the following conditions:

1) Neither the Font Software nor any of its individual components,
in Original or Modified Versions, may be sold by itself.

2) Original or Modified Versions of the Font Software may be bundled,
redistributed and/or sold with any software, provided that each copy
contains the above copyright notice and this license. These can be
included either as stand-alone text files, human-readable headers or
in the appropriate machine-readable metadata fields within text or
binary files as long as those fields can be easily viewed by the user.

3) No Modified Version of the Font Software may use the Reserved Font
Name(s) unless explicit written permission is granted by the corresponding
Copyright Holder. This restriction only applies to the primary font name as
presented to the users.

4) The name(s) of the Copyright Holder(s) or the Author(s) of the Font
Software shall not be used to promote, endorse or advertise any
Modified Version, except to acknowledge the contribution(s) of the
Copyright Holder(s) and the Author(s) or with their explicit written
permission.

5) The Font Software, modified or unmodified, in part or in whole,
must be distributed entirely under this license, and must not be
distributed under any other license. The requirement for fonts to
remain under this license does not apply to any document created
using the Font Software.

TERMINATION
This license becomes null and void if any of the above conditions are
not met.

DISCLAIMER
THE FONT SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT
OF COPYRIGHT, PATENT, TRADEMARK, OR OTHER RIGHT. IN NO EVENT SHALL THE
COPYRIGHT HOLDER BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
INCLUDING ANY GENERAL, SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL
DAMAGES, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF THE USE OR INABILITY TO USE THE FONT SOFTWARE OR FROM
OTHER DEALINGS IN THE FONT SOFTWARE.
```



### Creative Commons Attribution 3.0 Unported (CC BY 3.0)

Applies to: BlockKie.


Used under the Creative Commons Attribution 3.0 Unported license. You must give
appropriate credit, provide a link to the license, and indicate if changes were
made when redistributing. The full text ships next to this file as
`CC-BY-3.0.txt`. See <https://creativecommons.org/licenses/by/3.0/>.




---

Generated by `rake framework:release:fonts`. For documentation, visit
<https://trmnl.com/framework/docs/3.3/font_family>.
