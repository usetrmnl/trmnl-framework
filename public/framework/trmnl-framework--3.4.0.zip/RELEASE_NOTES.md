# Framework v3.4.0

Released on 2026-09-28.

## Framework Changes

- Themes can set their own font. `theme-slots.typeface($family)` puts one family on every vector text role, with Inter Variable and Inter as fallbacks. It keeps the framework's weights and smoothing, and device font sizes, line heights and Text Scale still apply.
- Card border art keeps its corners. Corner brackets stay square, the dotted outline keeps its drawn curve, and the solid outline follows the theme's corner setting, instead of every overlay being clipped to the same rounded corner.
- The card border overlay reads its radius from the new `--framework-slot-item-border-radius` slot, and `theme-slots.item-border(...)` sets it for the built-in art.

## Upgrade Notes

- Ship your font files and their license with a theme that uses `typeface()`, and load them with relative URLs so the theme works on any host.
- A theme that sets `--framework-slot-item-border-art` directly, not through `theme-slots.item-border(...)`, also sets `--framework-slot-item-border-radius` from `--framework-item-border-radius-outline` or `--framework-item-border-radius-corner-brackets`. Without it the overlay keeps the clip it had in 3.3.

## Documentation Changes

- The current docs track is 3.4. Links to `/framework/docs/3.3/...` redirect to it.
- Theme Slots covers custom typefaces, with a standalone example, and the card border radius slot.
- Painting Typography explains how the JavaScript readers pick up a theme font, and how to refresh copied styles after a theme switch.
- Theme Authoring covers portable theme exports: the compiled stylesheet, the source, the font files and the manifest.
- Font Family, Sass API and Sass Mixins link to the new typeface guide.
