# Framework v3.4.0

Released on 2026-09-28.

## Framework Changes

- Plugins and themes can use their own font. Add the `typeface` class to any container and name the font in `--framework-typeface`, and every text role inside uses it, with Inter Variable and Inter as fallbacks. Font sizes, line heights and Text Scale do not change.
- `typography.typeface($family)` is the same font rule for Sass, and themes use it as `theme-slots.typeface($family)`. A plugin's font wins inside its container, a theme's font applies everywhere else on the screen, and both replace the device's built-in fonts, in either stylesheet order.
- Card border art keeps its corners. Corner brackets stay square, the dotted outline keeps its drawn curve, and the solid outline follows the theme's corner setting, instead of every overlay being clipped to the same rounded corner.
- The card border overlay reads its radius from the new `--framework-slot-item-border-radius` slot, and `theme-slots.item-border(...)` sets it for the built-in art.

## Upgrade Notes

- A custom font needs its files: load them with `@font-face`. A theme ships the files and their license beside its stylesheet and loads them with relative URLs, so the theme works on any host.
- A theme that sets `--framework-slot-item-border-art` directly, not through `theme-slots.item-border(...)`, also sets `--framework-slot-item-border-radius` from `--framework-item-border-radius-outline` or `--framework-item-border-radius-corner-brackets`. Without it the overlay keeps the clip it had in 3.3.

## Documentation Changes

- The current docs track is 3.4. Links to `/framework/docs/3.3/...` redirect to it.
- The new Custom Typefaces page, in the Typography group, covers the `typeface` class, the Sass mixins, which font wins, what each device keeps, font files, and JavaScript.
- Font Family, Painting Typography, Sass API, Sass Mixins, CSS Variables, Themes, Theme Slots and the v3 overview link to it. Theme Slots also covers the card border radius slot.
- Painting Typography explains how the JavaScript readers pick up a custom font, and how to refresh copied styles after a theme switch.
- Authoring Themes covers portable theme exports: the compiled stylesheet, the source, the font files and the manifest.
