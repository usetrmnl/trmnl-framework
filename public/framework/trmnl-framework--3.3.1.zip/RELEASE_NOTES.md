# Framework v3.3.1

Released on 2026-08-31.

A maps release.

## Framework Changes

- Water reads clearly against land now, on every panel.
- Woodland and bare rock paint from their own slots, `map-forest` and `map-rock`, so natural landscapes have more depth.
- Generic landuse now carries a texture on 1-bit screens instead of dropping to bare white, so a built-up area reads as ground there too.
- `route()` and `dot()` draw bolder, so a route or a marker holds up over a busy map.
- Map fills land on the device pixel grid on screens whose scale is not a whole number, TRMNL X among them. They could beat against the grid, paint a neighbouring tone's texture, or come out flat with no texture at all; a horizontal band could cross the map painting the wrong texture below it; and boundary lines could go missing. Maps on those screens will look different from 3.3.0, and correct.
- The dark theme mirrors the light one.
- Framework development mode serves your own `plugins.js` again, so a JavaScript change is visible through a host app's renders.

## Upgrade Notes

- If your theme sets `map-green`, add `map-forest`. If it sets `map-sand`, add `map-rock`. Both are in the theme boilerplate.
- The black-and-yellow and white-and-red themes keep the water they had.
- Routes and markers draw thicker. Pass `width` or `radius` for the old sizes.

## Documentation Changes

- The Map examples moved to Atlanta, Berlin, Tiergarten and Central Park.
- The Map styles example sits at a zoom where the three presets actually differ.
- Fixed the floating card example's layout and the Strava example's stats.
