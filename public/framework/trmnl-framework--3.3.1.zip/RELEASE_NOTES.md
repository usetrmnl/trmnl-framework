# Framework v3.3.1

Released on 2026-08-31.

## Framework Changes

- TODO: Add notable framework CSS, JavaScript runtime, generated asset, utility behavior, or public API changes.

## Upgrade Notes

- TODO: Add user action required for this release, or remove this section if there is none.

## Documentation Changes

- TODO: Add notable docs, examples, guide, notice, generated markdown, or navigation changes.
