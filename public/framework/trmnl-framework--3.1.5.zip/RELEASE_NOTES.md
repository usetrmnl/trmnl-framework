# Framework v3.1.5

Released on 2026-07-16.

## Framework Changes

- Added Fluid Mashup placement modifiers for the `mashup--3x3` layout. Use `mashup-cell--col-*`, `mashup-cell--col-span-*`, `mashup-cell--row-*`, and `mashup-cell--row-span-*` to create custom tilings.
- Added Text Scale modifiers for changing framework typography independently from component dimensions, gaps, and text strokes. The available levels are `small` (80%), `regular` (100%), `large` (125%), and `xlarge` (150%).

## Documentation Changes

- Documented Fluid Mashup placement classes and updated the examples to use them.
- Added the Text Scale reference with usage guidance, an interactive preview, Scale combinations, and custom CSS guidance.
