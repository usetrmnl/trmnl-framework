# Framework v3.1.4

Released on 2026-07-15.

## Framework Changes

- Expanded explicit screen scale modifiers to cover framework gaps, pixel-based spacing and sizing utilities, image presets, flex basis utilities, and grid minimum track sizes.

No plugin changes are required. The expanded behavior applies when a `screen--scale-*` modifier is present.
