# Framework v3.1.3

Released on 2026-07-14.

## Framework Changes

- Added a 66% xxsmall screen scale for dense dynamic mashup layouts.
- Fixed dynamic 3x3 mashup cells so every cell draws the correct surface and frame, including cells that contain a full-size view.
- Applied compact title bars and cell-relative layout sizing to every dynamic cell across 1-bit, 2-bit, 4-bit, dark mode, and backdrop rendering.

## Documentation Changes

- Documented the 3.1 dynamic mashup grid with equal-tile, spanning-cell, and title-bar examples on the Mashup page.
