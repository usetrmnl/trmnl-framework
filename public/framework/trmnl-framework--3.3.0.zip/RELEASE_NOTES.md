# Framework v3.3.0

Released on 2026-08-22.

Framework 3.3 brings maps to plugins. Everything in it is opt-in and rides on the 3.2 foundation: themes, the TRMNLPaint paint API, and the adaptive charts and icons.

## New Features

### Adaptive maps

Maps join charts on TRMNLPaint. `TRMNLMaps` composes MapLibre GL JS styles from framework paint over OpenStreetMap vector tiles and ships inside the runtime, so a plotted map adapts to the device, bit depth, dark mode, and themes instead of carrying a fixed raster style, and it renders as a still frame with no interaction or animation.

Every layer is painted from new map slots (land, water, parks, fields, buildings, roads, rail, paths, boundaries, labels), so a map takes dither tiles on 1-bit, solids on 4-bit, hues on a color panel, and a theme's own tokens. Roads, rails, routes and markers are drawn as crisp fills on the pixel grid rather than anti-aliased lines, and place names are framework labels in the screen's own fonts with a text stroke, so they read on a busy 1-bit map. Four presets ship (`streets`, `minimal`, `outline`, `blank`), with `route()`, `dot()`, `fit()` and `decodePolyline()` for plotting your own data, a Strava activity among the examples.

### Map tiles from the framework

A map asks the host that served the page for its tiles, at `/framework/tiles/{z}/{x}/{y}.mvt`, and the engine answers by fetching each tile from the source the host configures (`Framework.tile_source_url`) and handing it on with the right type, encoding and cache headers. A plugin never names a tile host, and the data source is host configuration rather than a framework release. Nothing is stored: no tile data lives in the gem, on disk or in a database.

### Map slots for themes

Sixteen map slots join the theme slot set (`map-land`, `map-water`, `map-water-line`, `map-green`, `map-farmland`, `map-sand`, `map-area`, `map-site`, `map-building`, `map-transit`, `map-road`, `map-road-minor`, `map-path`, `map-rail`, `map-boundary`, `map-label`), every one a `bg-slot`, so a theme restyles a map with the same mixin it uses for every other component. The three shipped themes restate them.

### TRMNLPaint slot resolver and MapLibre adapter

`TRMNLPaint.slot(name, { kind })` resolves any component slot (background, text, or line) from the live cascade, and `TRMNLPaint.toMapLibre(fill)` shapes a Fill for MapLibre GL JS: a solid as a color, a dither tile as a registered pattern image that lands one tile pixel on one device pixel. `TRMNLPaint.scale()` now reports the device pixel ratio and dither ratio as well.

### Runtime readiness for maps

The terminalize pass ends by waiting for every attached map to go idle (`TRMNLMaps.settle()`, bounded), so `TRMNL_PLUGINS_READY` flips after the tiles, the widened lines and the labels have drawn. `TRMNLMaps.refresh()` rebuilds every watched map from the live cascade and settles it without another pass, for a host that rescales the screen after the pass the way a screenshot service sets its capture pixel ratio last.

## Upgrade Notes

Framework 3.3 is backward compatible with 3.0, 3.1 and 3.2: documented classes and attributes keep their meaning, and every 3.3 feature is opt-in.

- **MapLibre GL JS is a plugin dependency, not a framework one.** A map plugin loads `https://trmnl.com/js/maplibre-gl/5.24.0/maplibre-gl.js` and its stylesheet with classic tags, the way chart plugins load Highcharts. The framework vendors the same build and serves it next to the runtime for the docs. 5.24.0 is the last release with a UMD build; moving to 6.x is a separate decision.
- **Map tiles need a source on a host that renders them.** The default `Framework.tile_source_url` is OpenStreetMap's community endpoint, whose usage policy allows a docs site and forbids a device fleet. A host that renders map plugins for devices points the setting (or `TRMNL_FRAMEWORK_TILE_SOURCE_URL`) at its own Shortbread tile source first.
- **Screenshot renderers rescale after the pass.** A renderer that lays the page out at 1x and applies the capture pixel ratio afterwards calls `TRMNLMaps.refresh()` and awaits it before it freezes timers and captures, so the canvas is built for the pixels the capture has.

## Documentation Changes

- Added the Map page (Streets, Map styles, Markers and routes, Grayscale and color, Strava activity) under Components and the Painting Maps page under Paint, with the readiness and refresh contract on the Framework Runtime page.
- The current docs track is 3.3; 3.2 URLs redirect to their 3.3 twins. The 3.0 and 3.1 tracks stay frozen.
- Documented the tile endpoint and its configuration in the engine integration guide, the Open Source page and the README, and the map go-live checklist in `docs/MAPS_GO_LIVE.md`.
