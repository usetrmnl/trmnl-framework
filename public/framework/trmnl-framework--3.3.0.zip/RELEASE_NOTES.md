# Framework v3.3.0

Released on 2026-08-22.

Framework 3.3 brings maps to plugins. Everything in it is opt-in and rides on the 3.2 foundation: themes, the TRMNLPaint paint API, and the adaptive charts and icons.

## New Features

### Adaptive maps

Maps join charts on TRMNLPaint. `TRMNLMaps` composes MapLibre GL JS styles from framework paint over OpenStreetMap vector tiles and ships inside the runtime, so a plotted map adapts to the device, bit depth, dark mode, and themes instead of carrying a fixed raster style, and it renders as a still frame with no interaction or animation.

Every layer is painted from new map slots (land, water, parks, fields, buildings, roads, rail, paths, boundaries, labels), so a map takes dither tiles on 1-bit, solids on 4-bit, hues on a color panel, and a theme's own tokens. Roads, rails, routes and markers are drawn as crisp fills on the pixel grid rather than anti-aliased lines, and place names are framework labels in the screen's own fonts with a text stroke, so they read on a busy 1-bit map. Four presets ship (`streets`, `minimal`, `outline`, `blank`), with `route()`, `dot()`, `fit()` and `decodePolyline()` for plotting your own data, a Strava activity among the examples.

### Tile sources and keys

A map names no tile host by default: it fetches OpenStreetMap's public Shortbread tiles itself, on the free tier, so a plugin costs its host nothing. A plugin names its own source with `options({ tiles: { url, key } })`, a `{z}/{x}/{y}` template with `{key}` filled from the key, and a host hands a source to a plugin instance as `window.__TRMNL_MAPS__ = { tiles: { url, key } }`, which is how a plugin author's key or a user's key reaches a map without a key in the markup. The engine also serves TRMNL's own source, the `'trmnl'` preset at `/framework/tiles/{z}/{x}/{y}.mvt`, a pass-through from `Framework.tile_source_url` with the right type, encoding and cache headers; the docs use it, and nothing is stored in the gem, on disk or in a database.

### Map slots for themes

Sixteen map slots join the theme slot set (`map-land`, `map-water`, `map-water-line`, `map-green`, `map-farmland`, `map-sand`, `map-area`, `map-site`, `map-building`, `map-transit`, `map-road`, `map-road-minor`, `map-path`, `map-rail`, `map-boundary`, `map-label`), every one a `bg-slot`, so a theme restyles a map with the same mixin it uses for every other component. The three shipped themes restate them.

### TRMNLPaint slot resolver and MapLibre adapter

`TRMNLPaint.slot(name, { kind })` resolves any component slot (background, text, or line) from the live cascade, and `TRMNLPaint.toMapLibre(fill)` shapes a Fill for MapLibre GL JS: a solid as a color, a dither tile as a registered pattern image that lands one tile pixel on one device pixel. `TRMNLPaint.scale()` now reports the device pixel ratio and dither ratio as well.

### Runtime readiness for maps

The terminalize pass ends by waiting for every attached map to go idle (`TRMNLMaps.settle()`, bounded), so `TRMNL_PLUGINS_READY` flips after the tiles, the widened lines and the labels have drawn. `TRMNLMaps.refresh()` rebuilds every watched map from the live cascade and settles it without another pass, for a host that rescales the screen after the pass the way a screenshot service sets its capture pixel ratio last.

## Upgrade Notes

Framework 3.3 is backward compatible with 3.0, 3.1 and 3.2: documented classes and attributes keep their meaning, and every 3.3 feature is opt-in.

- **MapLibre GL JS is a plugin dependency, not a framework one.** A map plugin loads `https://trmnl.com/js/maplibre-gl/5.24.0/maplibre-gl.js` and its stylesheet with classic tags, the way chart plugins load Highcharts. The framework vendors the same build and serves it next to the runtime for the docs. 5.24.0 is the last release with a UMD build; moving to 6.x is a separate decision.
- **Map tiles ride the free tier by default.** The public default and the `'trmnl'` preset's default upstream are OpenStreetMap's community endpoint, whose usage policy allows light use and forbids a fleet. A map plugin that goes out to many devices brings its own source and key, or a host points `Framework.tile_source_url` (or `TRMNL_FRAMEWORK_TILE_SOURCE_URL`) at its own Shortbread tile source and injects a source per plugin instance.
- **Screenshot renderers rescale after the pass.** A renderer that lays the page out at 1x and applies the capture pixel ratio afterwards calls `TRMNLMaps.refresh()` and awaits it before it freezes timers and captures, so the canvas is built for the pixels the capture has.

## Documentation Changes

- Added the Map page (Streets, Map styles, Markers and routes, Grayscale and color, Strava activity) under Components and the Painting Maps page under Paint, with the readiness and refresh contract on the Framework Runtime page.
- The current docs track is 3.3; 3.2 URLs redirect to their 3.3 twins. The 3.0 and 3.1 tracks stay frozen.
- Documented the tile endpoint and its configuration in the engine integration guide, the Open Source page and the README, and the map go-live checklist in `docs/MAPS_GO_LIVE.md`.
