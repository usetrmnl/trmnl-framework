# Framework v3.1.8

Released on 2026-07-23.

## Framework Changes

- Fixed `inverse` inside a dark-mode screen to render a light subtree across bit depths and color palettes.

## Upgrade Notes

- None.

## Documentation Changes

- Added a dedicated Inverse utility page with collection and state-transition examples.
