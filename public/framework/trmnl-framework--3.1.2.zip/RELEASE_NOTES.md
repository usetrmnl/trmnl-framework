# Framework v3.1.2

Released on 2026-07-09.

## Framework Changes

- Introducing support for mashup 3x3 grid.
